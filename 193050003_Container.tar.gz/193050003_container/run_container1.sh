sudo ./container rootfs container1 netns1 veth0 veth1 192.168.1.10 192.168.1.11 proc
