sudo ./container rootfs container2 netns2 veth2 veth3 192.168.1.12 192.168.1.13 proc
