CS695 Assignment-3: Creating a container from scratch

submitted by: suraj kumar, 193050003
----------------------------------------------------------------------------------------------------------------------------------------------------------------
Steps to execute:

1. Download rootfs file system(from given link in assignment)
2. compile containerDemo.c
3. run create_net_nspace.sh
4. run run_container1.sh to run 1st container
5. put test_case.sh in rootfs file system
6. put any server.py file in rootfs file system( for location see test_case.sh)
7. run test_case.sh 
