sudo mkdir /sys/fs/cgroup/memory/memory_limit/
sudo ip netns add netns1
sudo ip netns add netns2
