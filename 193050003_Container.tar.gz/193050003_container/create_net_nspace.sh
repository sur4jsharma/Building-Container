sudo ip netns add netns1
sudo ip netns add netns2
